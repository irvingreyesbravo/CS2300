#
# Programing Assignment 2, Part A2
# Name: Irving Reyes Bravo
# Date: 10/26/2023
#

import numpy as np


# declare matrix A
matrixA = np.array([[1, -1, -1, 1],
                    [2, -3, -5, 4],
                    [-2, -1, -2, 2],
                    [3, -3, -1, 2]])
# declare inverse matrix A
transposeA = np.linalg.inv(matrixA)

# call function to read linear sequence of numbers from given file
with open("input-A22.txt", "r") as file:
    linearSequence = [int(num) for num in file.read().split()]

# declare variables to hold rows and appropriate sized columns
rows = 4
cols = len(linearSequence) // rows

# # if-statement that checks columns are a multiple of the number of rows
if len(linearSequence) % rows != 0:
    cols += 1

# if-statement that checks if sequence has the correct number of elements for a (4 x 4)
if len(linearSequence) % rows != 0:
    # declare variable to hold spaces needed to complete last column
    slotsNeeded = rows - (len(linearSequence) % rows)
    # increment list with zeros (slots needed to fill)
    linearSequence += [0] * slotsNeeded

# declare cypher matrix into appropriately sized column vectors
cipherMatrix = np.array(linearSequence).reshape(rows, cols)

# declare decoded matrix with inverse A times the cipher matrix
decodedMatrix = np.dot(transposeA, cipherMatrix)
# declare variable to hold the resulting matrix
decodedSequence = decodedMatrix.flatten()

# declare variable to hold the numbers in their corresponding characters
plainText = ''.join([chr(int(num)) for num in decodedSequence])

# display the decoded message
print("Decoded Message:")
print(plainText)
